module.exports = {
    host: "10.0.0.254",
    user: "signupapp",
    password: "Aa123123!@",
    database: "timetable",
};